delete from aade.param_dictionary_map t where t.DICTTABLE='1000' and t.ITEMCODE='HE';

insert into aade.param_dictionary_map (DICTTABLE, ITEMCODE, ITEMNAME_ZH, SOURCETYPE, SRCCODE, SRCNAME, ASSISTFLAG)
values ('1000', 'HE    ', '香港期货交易所', 'AAIA', 'XHKG', null, null);

commit;
