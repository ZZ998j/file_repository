DROP TABLE SRC.CF_CUSFUND_F;
-- Create table
create table SRC.CF_CUSFUND_F
(
  tdate     CHAR(12),
  accid     CHAR(18),
  KHBM	    char(8),
  CURR	    Char(7),
  JZHB	    Char(1),
  SRJC	    Number(14,2),
  SXF	    Number(14,2),
  HDSXF	    Number(14,2),
  PCYK	    Number(14,2),
  CRJ	    Number(14,2),
  QLJ	    Number(14,2),
  DRJC	    Number(14,2),
  FDYK      Number(14,2),
  QMQY	    Number(14,2),
  QQSZ	    Number(14,2),
  LMEWDZYK	Number(14,2),
  LMEBDBZJ	Number(14,2),
  KHCSBZJ	Number(14,2),
  ZYZJ	    Number(14,2),
  KHWCBZJ	Number(14,2),
  SSWCBZJ	Number(14,2),
  KYZJ      Number(14,2),
  XZJBZJ	Number(14,2),
  FXD       Number(14,2),
  ZHSZ	    Number(14,2),
  HL	    Number(14,8),
  USDZHSZ	Number(14,2),
  QTTSZJ	Number(14,2),
  imp_code  CHAR(18),
  imp_date  CHAR(8)
)
tablespace TS_SRC
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  )
nologging;
