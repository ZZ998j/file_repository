--��˰��ϸ��أ��Ϻ�A�ɲ��������ļ�abcsj*****.dbf������ZSMX.dbf��������BJZSMX.dbf��

--��������Դ
delete from aade.param_data_source where data_source_id in ('404','154','156');

insert into aade.param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION)
values (404, '20011903', '1', 'BJZSMX��˰��ϸ', 'bjzsmx', null, 0, 0, null, 'MXJSRQ', 'IMP_CODE', 405, 'SRC.NQ_BJZSMX', 'P60002930', 0, null, '��������˰��ϸ');

insert into aade.param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION)
values (154, '20010601', '1', 'A�ɲ��������ļ�', 'abcsj', null, 0, 0, null, 'TZRQ', 'IMP_CODE', 155, 'src.sh_abcsj', 'P60002910', 0, null, 'A�ɲ��������ļ�');

insert into aade.param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION)
values (156, '20010602', '1', '��˰��ϸ��Ϣ��', 'ZSMX', null, 0, 0, null, 'MXJSRQ', 'IMP_CODE', 157, 'src.sz_zsmx', 'P60002920', 0, null, '��˰��ϸ��Ϣ��');

--data_meta
delete from aade.data_meta where data_source_id in ('404','156','154');

insert into aade.data_meta (DATA_META_ID, DATA_SOURCE_ID, DATA_META_DESC, DATA_META_TYPE, POS_START, POS_END, REFERENCE_FIELD_ID, SPEC_FIELD_NAME)
values (40401, 404, 'BJZSMX��˰��ϸ��Ϣ��', '6', '', '', null, '@data_field');

insert into aade.data_meta (DATA_META_ID, DATA_SOURCE_ID, DATA_META_DESC, DATA_META_TYPE, POS_START, POS_END, REFERENCE_FIELD_ID, SPEC_FIELD_NAME)
values (15601, 156, '��˰��ϸ��Ϣ��', '6', '', '', null, '@data_field');

insert into aade.data_meta (DATA_META_ID, DATA_SOURCE_ID, DATA_META_DESC, DATA_META_TYPE, POS_START, POS_END, REFERENCE_FIELD_ID, SPEC_FIELD_NAME)
values (15401, 154, 'A�ɲ��������ļ�', '6', '', '', null, '@data_field');

--���Ӳ˵�
delete from sysmanage.param_privmenu p where p.menu_id = '200106';

insert into sysmanage.param_privmenu (MENU_ID, MENU_LEVEL, MENU_NAME, FUNC_ID, IS_MENU, IS_FUNC)
values (200106, '200106', '��Ϣ����', 200106, '0', '1');

--���������ֵ�
delete from aade.param_dictionary d where d.dicttable = '9220';

insert into aade.param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9220', '01', '�Ͻ���--A�ɲ��������ļ�', null, null, '0');

insert into aade.param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9220', '02', '���--��˰��ϸ��Ϣ��', null, null, '0');

delete from aade.param_dictionary d where trim(d.dicttable) = '9260' and trim(d.itemcode) in ('03');

insert into aade.param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9260', '03', '03-BJZSMX��˰��ϸ', null, null, '0');

--����Businessflag
delete from aade.param_businessflag where businessflag in ('2900','2910','2930');

insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('2900', '����˰���գ��Ϻ���', 'A', null, 1, 'CNY', 'CNY', '1', null, '1', 'ABCSJ', '0', 'CITICH', null, 'N', 'N', '2900', 'L');

insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('2910', '����˰���գ����ڣ�', 'A', null, 1, 'CNY', 'CNY', '1', null, '1', 'ZSMX', '0', 'CITICH', null, 'N', 'N', '2910', 'L');

insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('2930', '����˰���գ������壩', 'N', null, 1, 'CNY', 'CNY', '1', null, '1', 'BJZSMX', '0', 'CITICH', null, 'N', 'N', '2930', 'L');

--����param_dictionary_map����AAIA�������Ͷ�Ӧ��ϵ
delete from aade.param_dictionary_map dm where dm.dicttable = '1004' and dm.itemcode in ('2900','2910','2930');

insert into aade.param_dictionary_map (DICTTABLE, ITEMCODE, ITEMNAME_ZH, SOURCETYPE, SRCCODE, SRCNAME, ASSISTFLAG)
values ('1004', '2900', '����˰���գ��Ϻ���', 'AAIA', 'PTX1', null, null);

insert into aade.param_dictionary_map (DICTTABLE, ITEMCODE, ITEMNAME_ZH, SOURCETYPE, SRCCODE, SRCNAME, ASSISTFLAG)
values ('1004', '2910', '����˰���գ����ڣ�', 'AAIA', 'PTX2', null, null);

insert into aade.param_dictionary_map (DICTTABLE, ITEMCODE, ITEMNAME_ZH, SOURCETYPE, SRCCODE, SRCNAME, ASSISTFLAG)
values ('1004', '2930', '����˰���գ������壩', 'AAIA', 'PTX4', null, null);

--���ֶΣ�������BJZSMX.dbf��
delete from aade.data_field_info dfi where dfi.data_source_id in ('404', '405');
--Դ��
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404001, 404, 'MXJSZH', '1', null, null, null, 1, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404002, 404, 'MXBFZH', '1', null, null, null, 2, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404003, 404, 'MXYWLB', '1', null, null, null, 3, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404004, 404, 'MXZQDH', '1', null, null, null, 4, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404005, 404, 'MXXWDH', '1', null, null, null, 5, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404006, 404, 'MXGDDM', '1', null, null, null, 6, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404007, 404, 'MXJCGS', '2', null, null, null, 7, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404008, 404, 'MXJCRQ', '3', null, null, null, 8, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404009, 404, 'MXJSRQ', '3', null, null, null, 9, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404010, 404, 'MXJSLS', '1', null, null, null, 10, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404011, 404, 'MXFSJE', '2', null, null, null, 11, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404012, 404, 'MXHBDH', '1', null, null, null, 12, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404013, 404, 'MXFSRQ', '3', null, null, null, 13, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (404014, 404, '@data_field', '1', null, null, null, 14, null);

--Ŀ���
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405001, 405, 'MXJSZH', '1', null, null, null, 1, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405002, 405, 'MXBFZH', '1', null, null, null, 2, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405003, 405, 'MXYWLB', '1', null, null, null, 3, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405004, 405, 'MXZQDH', '1', null, null, null, 4, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405005, 405, 'MXXWDH', '1', null, null, null, 5, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405006, 405, 'MXGDDM', '1', null, null, null, 6, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405007, 405, 'MXJCGS', '2', null, null, null, 7, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405008, 405, 'MXJCRQ', '1', null, null, null, 8, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405009, 405, 'MXJSRQ', '1', null, null, null, 9, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405010, 405, 'MXJSLS', '1', null, null, null, 10, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405011, 405, 'MXFSJE', '2', null, null, null, 11, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405012, 405, 'MXHBDH', '1', null, null, null, 12, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405013, 405, 'MXFSRQ', '1', null, null, null, 13, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405014, 405, 'IMP_CODE', '1', null, null, null, 14, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (405015, 405, 'IMP_DATE', '1', null, null, null, 15, null);


--����ӳ���ϵ
delete from aade.data_field_mapping dfm where dfm.field_mapping_id between 404001 and 404014;

insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404001, 404001, 405001);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404002, 404002, 405002);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404003, 404003, 405003);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404004, 404004, 405004);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404005, 404005, 405005);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404006, 404006, 405006);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404007, 404007, 405007);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404008, 404008, 405008);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404009, 404009, 405009);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404010, 404010, 405010);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404011, 404011, 405011);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404012, 404012, 405012);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404013, 404013, 405013);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (404014, 404014, 405014);

--���ֶΣ��Ϻ�A�ɲ��������ļ�abcsj*****.dbf��
delete from aade.data_field_info dfi where dfi.data_source_id in ('154', '155');
--Դ��
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154001, 154, 'SCDM', '1', null, null, null, 1, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154002, 154, 'TZLB', '1', null, null, null, 2, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154003, 154, 'TZRQ', '1', null, null, null, 3, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154004, 154, 'QSBH', '1', null, null, null, 4, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154005, 154, 'XH', '1', null, null, null, 5, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154006, 154, 'ZQZH', '1', null, null, null, 6, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154007, 154, 'ZQDM', '1', null, null, null, 7, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154008, 154, 'ZQLB', '1', null, null, null, 8, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154009, 154, 'LTLX', '1', null, null, null, 9, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154010, 154, 'QYLB', '1', null, null, null, 10, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154011, 154, 'GPNF', '1', null, null, null, 11, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154012, 154, 'ZH1', '1', null, null, null, 12, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154013, 154, 'ZH2', '1', null, null, null, 13, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154014, 154, 'RQ1', '1', null, null, null, 14, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154015, 154, 'RQ2', '1', null, null, null, 15, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154016, 154, 'RQ3', '1', null, null, null, 16, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154017, 154, 'JE1', '1', null, null, null, 17, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154018, 154, 'JE2', '1', null, null, null, 18, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154019, 154, 'JE3', '1', null, null, null, 19, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154020, 154, 'JG1', '1', null, null, null, 20, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154021, 154, 'JG2', '1', null, null, null, 21, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154022, 154, 'BL1', '1', null, null, null, 22, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154023, 154, 'BL2', '1', null, null, null, 23, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154024, 154, 'SL1', '1', null, null, null, 24, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154025, 154, 'SL2', '1', null, null, null, 25, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154026, 154, 'FZDM', '1', null, null, null, 26, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154027, 154, 'BZ', '1', null, null, null, 27, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154028, 154, 'BY', '1', null, null, null, 28, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (154029, 154, '@data_field', '1', null, null, null, 29, null);

--Ŀ���
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155001, 155, 'SCDM', '1', null, null, null, 1, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155002, 155, 'TZLB', '1', null, null, null, 2, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155003, 155, 'TZRQ', '1', null, null, null, 3, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155004, 155, 'QSBH', '1', null, null, null, 4, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155005, 155, 'XH', '1', null, null, null, 5, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155006, 155, 'ZQZH', '1', null, null, null, 6, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155007, 155, 'ZQDM', '1', null, null, null, 7, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155008, 155, 'ZQLB', '1', null, null, null, 8, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155009, 155, 'LTLX', '1', null, null, null, 9, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155010, 155, 'QYLB', '1', null, null, null, 10, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155011, 155, 'GPNF', '1', null, null, null, 11, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155012, 155, 'ZH1', '1', null, null, null, 12, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155013, 155, 'ZH2', '1', null, null, null, 13, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155014, 155, 'RQ1', '1', null, null, null, 14, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155015, 155, 'RQ2', '1', null, null, null, 15, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155016, 155, 'RQ3', '1', null, null, null, 16, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155017, 155, 'JE1', '2', null, null, null, 17, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155018, 155, 'JE2', '2', null, null, null, 18, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155019, 155, 'JE3', '2', null, null, null, 19, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155020, 155, 'JG1', '2', null, null, null, 20, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155021, 155, 'JG2', '2', null, null, null, 21, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155022, 155, 'BL1', '2', null, null, null, 22, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155023, 155, 'BL2', '2', null, null, null, 23, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155024, 155, 'SL1', '2', null, null, null, 24, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155025, 155, 'SL2', '2', null, null, null, 25, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155026, 155, 'FZDM', '1', null, null, null, 26, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155027, 155, 'BZ', '1', null, null, null, 27, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155028, 155, 'BY', '1', null, null, null, 28, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155029, 155, 'IMP_CODE', '1', null, null, null, 29, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (155030, 155, 'IMP_DATE', '1', null, null, null, 30, null);

--����ӳ���ϵ
delete from aade.data_field_mapping dfm where dfm.field_mapping_id between 154001 and 154029;

insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154001, 154001, 155001);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154002, 154002, 155002);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154003, 154003, 155003);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154004, 154004, 155004);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154005, 154005, 155005);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154006, 154006, 155006);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154007, 154007, 155007);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154008, 154008, 155008);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154009, 154009, 155009);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154010, 154010, 155010);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154011, 154011, 155011);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154012, 154012, 155012);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154013, 154013, 155013);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154014, 154014, 155014);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154015, 154015, 155015);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154016, 154016, 155016);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154017, 154017, 155017);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154018, 154018, 155018);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154019, 154019, 155019);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154020, 154020, 155020);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154021, 154021, 155021);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154022, 154022, 155022);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154023, 154023, 155023);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154024, 154024, 155024);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154025, 154025, 155025);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154026, 154026, 155026);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154027, 154027, 155027);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154028, 154028, 155028);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (154029, 154029, 155029);

--���ֶΣ�����ZSMX.dbf��
delete from aade.data_field_info dfi where dfi.data_source_id in ('156', '157');
--Դ��
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156001, 156, 'MXJSZH', '1', null, null, null, 1, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156002, 156, 'MXBFZH', '1', null, null, null, 2, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156003, 156, 'MXYWLB', '1', null, null, null, 3, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156004, 156, 'MXZQDH', '1', null, null, null, 4, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156005, 156, 'MXXWDH', '1', null, null, null, 5, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156006, 156, 'MXGDDM', '1', null, null, null, 6, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156007, 156, 'MXJCGS', '2', null, null, null, 7, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156008, 156, 'MXJCRQ', '3', null, null, null, 8, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156009, 156, 'MXJSRQ', '3', null, null, null, 9, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156010, 156, 'MXJSLS', '1', null, null, null, 10, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156011, 156, 'MXFSJE', '2', null, null, null, 11, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156012, 156, 'MXHBDH', '1', null, null, null, 12, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156013, 156, 'MXFSRQ', '3', null, null, null, 13, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (156014, 156, '@data_field', '1', null, null, null, 14, null);

--Ŀ���
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157001, 157, 'MXJSZH', '1', null, null, null, 1, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157002, 157, 'MXBFZH', '1', null, null, null, 2, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157003, 157, 'MXYWLB', '1', null, null, null, 3, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157004, 157, 'MXZQDH', '1', null, null, null, 4, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157005, 157, 'MXXWDH', '1', null, null, null, 5, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157006, 157, 'MXGDDM', '1', null, null, null, 6, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157007, 157, 'MXJCGS', '2', null, null, null, 7, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157008, 157, 'MXJCRQ', '1', null, null, null, 8, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157009, 157, 'MXJSRQ', '1', null, null, null, 9, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157010, 157, 'MXJSLS', '1', null, null, null, 10, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157011, 157, 'MXFSJE', '2', null, null, null, 11, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157012, 157, 'MXHBDH', '1', null, null, null, 12, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157013, 157, 'MXFSRQ', '1', null, null, null, 13, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157014, 157, 'IMP_CODE', '1', null, null, null, 14, null);
insert into aade.data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (157015, 157, 'IMP_DATE', '1', null, null, null, 15, null);

--����ӳ���ϵ
delete from aade.data_field_mapping dfm where dfm.field_mapping_id between 156001 and 156014;

insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156001, 156001, 157001);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156002, 156002, 157002);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156003, 156003, 157003);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156004, 156004, 157004);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156005, 156005, 157005);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156006, 156006, 157006);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156007, 156007, 157007);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156008, 156008, 157008);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156009, 156009, 157009);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156010, 156010, 157010);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156011, 156011, 157011);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156012, 156012, 157012);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156013, 156013, 157013);
insert into AADE.DATA_FIELD_MAPPING (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (156014, 156014, 157014);

--�ύ
commit;