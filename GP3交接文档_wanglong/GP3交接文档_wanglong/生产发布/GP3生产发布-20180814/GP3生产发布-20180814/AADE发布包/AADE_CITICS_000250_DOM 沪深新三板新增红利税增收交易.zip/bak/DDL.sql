
drop table SRC.NQ_BJZSMX;

drop table SRC.SH_ABCSJ;

drop table SRC.SZ_ZSMX;
