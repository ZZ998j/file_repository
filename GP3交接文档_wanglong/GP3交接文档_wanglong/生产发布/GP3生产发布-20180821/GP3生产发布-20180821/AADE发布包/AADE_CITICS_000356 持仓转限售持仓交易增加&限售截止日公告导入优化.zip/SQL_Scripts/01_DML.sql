---ɾ���õ�������---
delete from param_dictionary where dicttable='9252' and itemcode='05';
commit;
---data_field_info--
delete from aade.data_field_info t where t.data_source_id in ('450','451');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450001','450','tradetype','1','','','','1','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450002','450','tradedate','1','','','','2','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450003','450','settlementdate','1','','','','3','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450004','450','settlementdate_old','1','','','','4','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450005','450','portfoliocode','1','','','','5','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450006','450','shareholdaccount','1','','','','6','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450007','450','assetidentifier','1','','','','7','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450008','450','tradequantity','2','','','','8','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450009','450','tradestatus','1','','','','9','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450010','450','assettype','1','','','','10','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450011','450','@busi_date','1','','','','11','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451001','451','tradetype','1','','','','1','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451002','451','tradedate','1','','','','2','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451003','451','settlementdate','1','','','','3','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451004','451','settlementdate_old','1','','','','4','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451005','451','portfoliocode','1','','','','5','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451006','451','shareholdaccount','1','','','','6','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451007','451','assetidentifier','1','','','','7','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451008','451','tradequantity','2','','','','8','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451009','451','tradestatus','1','','','','9','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451010','451','assettype','1','','','','10','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451011','451','IMP_DATE','1','','','','11','');
---data_field_mapping--
delete from aade.data_field_mapping t where t.field_mapping_id between '450001' and '450011';
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450001','450001','451001');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450002','450002','451002');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450003','450003','451003');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450004','450004','451004');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450005','450005','451005');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450006','450006','451006');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450007','450007','451007');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450008','450008','451008');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450009','450009','451009');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450010','450010','451010');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450011','450011','451011');
commit;
---businessflag--
delete from aade.param_businessflag t where t.businessflag_related='5666';
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5666', 'STRATEת����-�¹����·ǹ���(PPAS)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5667', 'STRATEת����-���·ǹ�������(PPAA)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5668', 'IPOMKUת����-�¹�����IPO(IPOU)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5669', 'PROPREת����-��������(PURS)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5670', '��ͨת����-�¹����·ǹ���(PPAS)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5671', '��ͨת����-���·ǹ�������(PPAA)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5672', '��ͨת����-�¹�����IPO(IPOU)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5673', '��ͨת����-��������(PURS)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5674', '�����ڱ��-�¹����·ǹ���(PPAS)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5675', '�����ڱ��-���·ǹ�������(PPAA)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5676', '�����ڱ��-�¹�����IPO(IPOU)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5677', '�����ڱ��-��������(PURS)', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
--param_1004--
delete from aade.param_dictionary_map t where t.dicttable='1004' and t.itemcode
in ('5666','5667','5668','5669','5670','5671','5672','5673','5674','5675','5676','5677');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5666','STRATEת����-�¹����·ǹ���(PPAS)','AAIA','MIS1','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5667','STRATEת����-���·ǹ�������(PPAA)','AAIA','MIS2','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5668','IPOMKUת����-�¹�����IPO(IPOU)','AAIA','MIS3','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5669','PROPREת����-��������(PURS)','AAIA','MIS4','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5670','��ͨת����-�¹����·ǹ���(PPAS)','AAIA','MPS1','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5671','��ͨת����-���·ǹ�������(PPAA)','AAIA','MPS2','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5672','��ͨת����-�¹�����IPO(IPOU)','AAIA','MPS3','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5673','��ͨת����-��������(PURS)','AAIA','MPS4','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5674','�����ڱ��-�¹����·ǹ���(PPAS)','AAIA','MRC1','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5675','�����ڱ��-���·ǹ�������(PPAA)','AAIA','MRC2','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5676','�����ڱ��-�¹�����IPO(IPOU)','AAIA','MRC3','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5677','�����ڱ��-��������(PURS)','AAIA','MRC4','','');
commit;

