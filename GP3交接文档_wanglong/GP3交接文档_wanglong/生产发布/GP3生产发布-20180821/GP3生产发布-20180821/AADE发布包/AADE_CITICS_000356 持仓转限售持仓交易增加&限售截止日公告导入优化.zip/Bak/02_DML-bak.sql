--param_data_source--
delete from param_data_source where function_id='10010305';
insert into param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION, FULL_PATH_JUDGE_FLAG)
values (626,'10010305','3','��֤��ͨ���޹�Ʊ�������ۿ������ļ�','*nts_liq_dis','|', 0, 0, null,'GZR', null, 627,'src.zz_nts_liq_dis','P60009193', 0, null,'��֤��ͨ���޹�Ʊ�������ۿ����ݱ�','0');
commit;
--param_dictionary--��˾��Ϊ���浼�뵼��--
delete from param_dictionary where dicttable='9252' and trim(itemcode) ='05';
insert into param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9252','05','��֤���۽�ֹ��', null, null,'0');
commit;

delete from aade.param_data_source t where t.data_source_id='450';
insert into aade.param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION, FULL_PATH_JUDGE_FLAG)
values (450, '20012301', '2', '��ʼ������ά��', 'Manual_Lockperiod_', null, 1, 0, null, 'IMP_DATE', '', 451, 'src.manual_lockperiod', 'P60004090', 0, '2', '���޹�ת��ͨ��������', '0');

delete from aade.data_field_info t where t.data_source_id in ('450','451');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450001','450','tradetype','1','','','','1','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450002','450','tradedate','1','','','','2','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450003','450','settlementdate','1','','','','3','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450004','450','portfoliocode','1','','','','4','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450005','450','shareholdaccount','1','','','','5','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450006','450','assetidentifier','1','','','','6','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450007','450','tradequantity','2','','','','7','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450008','450','tradestatus','1','','','','8','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450009','450','assettype','1','','','','9','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450010','450','@busi_date','1','','','','10','');

insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451001','451','tradetype','1','','','','1','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451002','451','tradedate','1','','','','2','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451003','451','settlementdate','1','','','','3','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451004','451','portfoliocode','1','','','','4','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451005','451','shareholdaccount','1','','','','5','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451006','451','assetidentifier','1','','','','6','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451007','451','tradequantity','2','','','','7','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451008','451','tradestatus','1','','','','8','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451009','451','assettype','1','','','','9','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451010','451','IMP_DATE','1','','','','10','');

delete from aade.data_field_mapping t where t.field_mapping_id between '450001' and '450010';
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450001','450001','451001');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450002','450002','451002');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450003','450003','451003');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450004','450004','451004');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450005','450005','451005');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450006','450006','451006');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450007','450007','451007');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450008','450008','451008');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450009','450009','451009');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450010','450010','451010');

delete from aade.param_businessflag t where t.businessflag_related='5666';
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5666', '��������ת������-�ǹ�������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5667', '��������ת������-��������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5668', '��������ת������-�ɶ�����', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5669', '��������ת������-��������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5670', '��ͨת������-�ǹ�������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5671', '��ͨת������-��������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5672', '��ͨת������-�ɶ�����', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5673', '��ͨת������-��������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');

delete from aade.param_dictionary_map t where t.dicttable='1004' and t.itemcode
in ('5666','5667','5668','5669','5670','5671','5672','5673');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5666','��������ת������-�ǹ�������','AAIA','MIS1','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5667','��������ת������-��������','AAIA','MIS2','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5668','��������ת������-�ɶ�����','AAIA','MIS3','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5669','��������ת������-��������','AAIA','MIS4','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5670','��ͨת������-�ǹ�������','AAIA','MPS1','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5671','��ͨת������-��������','AAIA','MPS2','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5672','��ͨת������-�ɶ�����','AAIA','MPS3','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5673','��ͨת������-��������','AAIA','MPS4','','');

commit;



