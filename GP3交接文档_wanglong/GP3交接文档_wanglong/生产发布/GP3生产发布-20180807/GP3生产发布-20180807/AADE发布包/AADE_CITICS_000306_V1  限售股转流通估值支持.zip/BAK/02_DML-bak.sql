--��֤������ͨ��������--
--param_data_source--
delete from param_data_source where function_id='1001020117';
--param_data_source--
delete from param_data_source where function_id='10010305';
commit;
--data_field_info--
delete from data_field_mapping where source_field_id in ( select field_id from data_field_info where data_source_id in ('626','627'));
delete from data_field_info where data_source_id in ('626','627');
--param_dictionary--���鵼�뵼��
delete from param_dictionary where dicttable='9101' and itemcode='17';
delete from param_dictionary where dicttable='9120' and itemcode='ZZLIQ';
commit;
--param_dictionary--��˾��Ϊ���浼�뵼��--
delete from param_dictionary where dicttable='9252' and trim(itemcode) ='05';
commit;
delete from param_dictionary where dicttable='9171' and trim(itemcode) in ('04','05');
commit;
--��������--
delete from param_dictionary_map where dicttable in ('9101','9102') and SOURCETYPE='AADE' and itemcode='ZZLIQ';
delete from param_dictionary_map where dicttable in ('9101','9102') and SOURCETYPE='AAIA' and itemcode='ZZLIQ';
delete from aade.quote_export where market_str='ZZLIQ';
commit;

--MIAO--
delete from sysmanage.param_privmenu t where t.menu_id='300114';
delete from aade.param_dictionary t where t.dicttable='9234';
-----miao����
delete from sysmanage.param_privmenu t where t.menu_id='200123';
delete from aade.param_data_source t where t.data_source_id='450';
delete from aade.data_field_info t where t.data_source_id in ('450','451');
delete from aade.data_field_mapping t where t.field_mapping_id between '450001' and '450010';
delete from aade.param_businessflag t where t.businessflag_related='5666';
delete from aade.param_dictionary_map t where t.dicttable='1004' and t.itemcode
in ('5666','5667','5668','5669','5670','5671','5672','5673');
delete from aade.param_dictionary_map t where t.dicttable='5020' and t.itemcode='MANLOC';
delete from aade.data_meta t where t.data_meta_id='450001';
delete from aade.param_dictionary t where t.dicttable='9333';
delete from aade.param_dict_list t where t.dicttable='9333';


commit;
