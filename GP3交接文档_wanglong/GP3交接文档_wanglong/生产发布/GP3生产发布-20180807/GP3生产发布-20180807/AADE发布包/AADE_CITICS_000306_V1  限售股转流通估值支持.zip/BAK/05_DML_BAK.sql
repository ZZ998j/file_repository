DELETE param_dictionary WHERE TRIM(Dicttable)='9101' AND TRIM(ITEMCODE) = '20';

DELETE param_data_source X where TRIM(X.Function_Id) = '1001020120';

DELETE data_field_mapping WHERE FIELD_MAPPING_ID IN(select FIELD_ID from data_field_info WHERE data_source_id in (650,651));

DELETE data_field_info WHERE data_source_id in (650,651);

COMMIT;