--����--
 --SRC.ZZ_NTS_LIQ_DIS--
drop table SRC.ZZ_NTS_LIQ_DIS;  
 --aade.quote-- 
 alter table aade.quote drop column RESTRICTSHARE;
 alter table aade.quote drop column RESTRICTENDDATE;
 --aaia.aaia_quote--
 alter table aaia.aaia_quote drop column RESTRICTSHARE;
 alter table aaia.aaia_quote drop column RESTRICTENDDATE;
  --aade.quote_archive-- 
 alter table aade.quote_archive drop column RESTRICTSHARE;
 alter table aade.quote_archive drop column RESTRICTENDDATE;
 --aaia.aaia_quote_archive--
 alter table aaia.aaia_quote_archive drop column RESTRICTSHARE;
 alter table aaia.aaia_quote_archive drop column RESTRICTENDDATE;
---��˾��Ϊ���洦����---
drop table NTS_LIQ_DIS_DATE_TEMP; 
-- nts_liq_dis_date --
drop table nts_liq_dis_date;

--MIAO--
drop  table src.gp3_position;
drop table aade.gp3_position_compare;
----------miao����

drop table src.manual_lockperiod;
