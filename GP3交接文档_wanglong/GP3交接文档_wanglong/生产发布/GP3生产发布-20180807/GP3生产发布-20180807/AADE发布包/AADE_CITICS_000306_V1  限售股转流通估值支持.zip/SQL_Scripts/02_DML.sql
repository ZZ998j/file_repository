--��֤������ͨ��������--
--param_data_source--
delete from param_data_source where function_id='1001020117';
insert into param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION, FULL_PATH_JUDGE_FLAG)
values (626,'1001020117','3','��֤��ͨ���޹�Ʊ�������ۿ������ļ�','*nts_liq_dis','|', 0, 0, null,'GZR', null, 627,'src.zz_nts_liq_dis','P60009191', 0, null,'��֤��ͨ���޹�Ʊ�������ۿ����ݱ�','0');
--param_data_source--
delete from param_data_source where function_id='10010305';
insert into param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION, FULL_PATH_JUDGE_FLAG)
values (626,'10010305','3','��֤��ͨ���޹�Ʊ�������ۿ������ļ�','*nts_liq_dis','|', 0, 0, null,'GZR', null, 627,'src.zz_nts_liq_dis','P60009193', 0, null,'��֤��ͨ���޹�Ʊ�������ۿ����ݱ�','0');
commit;
--data_field_info--
delete from data_field_info where data_source_id in ('626','627');
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626001, 626,'GZR','1', null, null, null, 1, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626002, 626,'GPDM','1', null, null, null, 2, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626003, 626,'XSQJSR','1', null, null, null, 3, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626004, 626,'GFBDGGR','1', null, null, null, 4, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626005, 626,'SSHY','1', null, null, null, 5, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626006, 626,'DYHYZS','1', null, null, null, 6, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626007, 626,'SYXSQ','2', null, null, null, 7, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626008, 626,'LDXZK','2', null, null, null, 8, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (626009, 626,'BL','1', null, null, null, 9, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627001, 627,'GZR','1', null, null, null, 1, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627002, 627,'GPDM','1', null, null, null, 2, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627003, 627,'XSQJSR','1', null, null, null, 3, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627004, 627,'GFBDGGR','1', null, null, null, 4, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627005, 627,'SSHY','1', null, null, null, 5, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627006, 627,'DYHYZS','1', null, null, null, 6, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627007, 627,'SYXSQ','2', null, null, null, 7, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627008, 627,'LDXZK','2', null, null, null, 8, null);
insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (627009, 627,'BL','1', null, null, null, 9, null);
--data_field_mapping--
delete from data_field_mapping where source_field_id in ( select field_id from data_field_info where data_source_id in ('626','627'));
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626001, 626001, 627001);
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626002, 626002, 627002);
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626003, 626003, 627003);
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626004, 626004, 627004);
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626005, 626005, 627005);
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626006, 626006, 627006);
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626007, 626007, 627007);
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626008, 626008, 627008);
insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (626009, 626009, 627009);
--param_dictionary--���鵼�뵼��
delete from param_dictionary where dicttable='9101' and itemcode='17';
insert into param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9101','17','��֤���޹�Ʊ�������ۿ�', null, null,'0');
delete from param_dictionary where dicttable='9120' and itemcode='ZZLIQ';
insert into param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9120','ZZLIQ','��֤������ͨ����', null, null,'0');
commit;
--param_dictionary--��˾��Ϊ���浼�뵼��--
delete from param_dictionary where dicttable='9252' and trim(itemcode) ='05';
insert into param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9252','05','��֤���۽�ֹ��', null, null,'0');
commit;
delete from param_dictionary where dicttable='9171' and trim(itemcode) in ('04','05');
insert into param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9171','04','�Ͻ���', null, null,'0');
insert into param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9171','05','���', null, null,'0');
commit;

--��������--
delete from param_dictionary_map where dicttable in ('9101','9102') and SOURCETYPE='AADE' and itemcode='ZZLIQ';
insert into param_dictionary_map (DICTTABLE, ITEMCODE, ITEMNAME_ZH, SOURCETYPE, SRCCODE, SRCNAME, ASSISTFLAG)
values ('9101','ZZLIQ','��֤������ͨ����','AADE','10805200', null, null);
delete from param_dictionary_map where dicttable in ('9101','9102') and SOURCETYPE='AAIA' and itemcode='ZZLIQ';
insert into param_dictionary_map (DICTTABLE, ITEMCODE, ITEMNAME_ZH, SOURCETYPE, SRCCODE, SRCNAME, ASSISTFLAG)
values ('9101','ZZLIQ','��֤������ͨ����','AAIA','30805010', null, null);
delete from aade.quote_export where market_str='ZZLIQ';
insert into aade.quote_export (MARKET_STR, EXPORT_TYPE, PRICEPROVIDERIDENTIFIER, PRICETYPE, QUOTATIONPLACE, ASSETCLASS)
values ('ZZLIQ','AADE','CSIL','@','@','TAUX');
insert into aade.quote_export (MARKET_STR, EXPORT_TYPE, PRICEPROVIDERIDENTIFIER, PRICETYPE, QUOTATIONPLACE, ASSETCLASS)
values ('ZZLIQ','AAIA','CSIL','@','@','TAUX');
commit;



--MIAO---
delete from sysmanage.param_privmenu t where t.menu_id='300114';
insert into sysmanage.param_privmenu (MENU_ID, MENU_LEVEL, MENU_NAME, FUNC_ID, IS_MENU, IS_FUNC)
values (300114, '300114', '���۹ɲ�ѯ�ȶ�', 300114, '0', '1');

delete from aade.param_dictionary t where t.dicttable='9244';
insert into aade.param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9244', '1 ', 'IPORS1', '�ǹ�������', null, '1');

insert into aade.param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9244', '2 ', 'IPORS2', '��������', null, '1');

insert into aade.param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9244', '3 ', 'IPORS3', '�ɶ�����', null, '1');

insert into aade.param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9244', '4 ', 'IPORS4', '��������', null, '1');


delete from aade.param_dict_list t where t.dicttable='9244';
insert into aade.param_dict_list(dicttable, dicttablename, datatype, opright, dicttabledescription)
values('9244','GP3�ֲ�״̬','','','');

------------miao����
delete from sysmanage.param_privmenu t where t.menu_id='200123';
insert into sysmanage.param_privmenu(menu_id, menu_level, menu_name, func_id, is_menu, is_func)
values(200123,200123,'���޹�������','200123','0','1');

delete from aade.param_data_source t where t.data_source_id='450';
insert into aade.param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION, FULL_PATH_JUDGE_FLAG)
values (450, '20012301', '2', '��ʼ������ά��', 'Manual_Lockperiod_', null, 1, 0, null, 'IMP_DATE', '', 451, 'src.manual_lockperiod', 'P60004090', 0, '2', '���޹�ת��ͨ��������', '0');

delete from aade.data_field_info t where t.data_source_id in ('450','451');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450001','450','tradetype','1','','','','1','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450002','450','tradedate','1','','','','2','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450003','450','settlementdate','1','','','','3','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450004','450','portfoliocode','1','','','','4','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450005','450','shareholdaccount','1','','','','5','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450006','450','assetidentifier','1','','','','6','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450007','450','tradequantity','2','','','','7','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450008','450','tradestatus','1','','','','8','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450009','450','assettype','1','','','','9','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('450010','450','@busi_date','1','','','','10','');

insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451001','451','tradetype','1','','','','1','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451002','451','tradedate','1','','','','2','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451003','451','settlementdate','1','','','','3','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451004','451','portfoliocode','1','','','','4','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451005','451','shareholdaccount','1','','','','5','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451006','451','assetidentifier','1','','','','6','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451007','451','tradequantity','2','','','','7','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451008','451','tradestatus','1','','','','8','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451009','451','assettype','1','','','','9','');
insert into aade.data_field_info(field_id, data_source_id, field_name, field_type, field_position, field_length, field_round, field_order, divisor)
values('451010','451','IMP_DATE','1','','','','10','');

delete from aade.data_field_mapping t where t.field_mapping_id between '450001' and '450010';
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450001','450001','451001');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450002','450002','451002');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450003','450003','451003');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450004','450004','451004');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450005','450005','451005');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450006','450006','451006');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450007','450007','451007');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450008','450008','451008');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450009','450009','451009');
insert into aade.data_field_mapping(field_mapping_id, source_field_id, target_field_id)
values('450010','450010','451010');

delete from aade.param_businessflag t where t.businessflag_related='5666';
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5666', '��������ת������-�ǹ�������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5667', '��������ת������-��������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5668', '��������ת������-�ɶ�����', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5669', '��������ת������-��������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5670', '��ͨת������-�ǹ�������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5671', '��ͨת������-��������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5672', '��ͨת������-�ɶ�����', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');
insert into aade.param_businessflag (BUSINESSFLAG, BUSINESSNAME, INSTRUMENTSTYPE, TRADEDIR, SETTLEMENTLAG, TRADECURRENCY, SETTLEMENTCURRENCY, TRADESTATUS, POSITIONFLAG, FILEGROUPFLAG, SOURCEDATATYPE, IFFAREFALG, INTERFACEIDENTIFIER, PRICETYPE, SUM2UPPERPORTFOLIO, USEHSFORPORTFOLIO, BUSINESSFLAG_RELATED, LIST_TOTAL)
values ('5673', '��ͨת������-��������', 'Z', null, 0, 'CNY', 'CNY', '1', null, '0', 'MANLOC', '0', trim(get_company_interfacename)||'CT', null, 'N', 'N', '5666', 'L');



delete from aade.param_dictionary_map t where t.dicttable='1004' and t.itemcode
in ('5666','5667','5668','5669','5670','5671','5672','5673');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5666','��������ת������-�ǹ�������','AAIA','MIS1','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5667','��������ת������-��������','AAIA','MIS2','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5668','��������ת������-�ɶ�����','AAIA','MIS3','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5669','��������ת������-��������','AAIA','MIS4','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5670','��ͨת������-�ǹ�������','AAIA','MPS1','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5671','��ͨת������-��������','AAIA','MPS2','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5672','��ͨת������-�ɶ�����','AAIA','MPS3','','');
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('1004','5673','��ͨת������-��������','AAIA','MPS4','','');

delete from aade.param_dictionary_map t where t.dicttable='5020' and t.itemcode='MANLOC';
insert into aade.param_dictionary_map(dicttable, itemcode, itemname_zh, sourcetype, srccode, srcname, assistflag)
values('5020','MANLOC','���޹���ͨת��������','IMPT','1,2','','');

delete from aade.data_meta t where t.data_meta_id='450001';
insert into aade.data_meta(data_meta_id, data_source_id, data_meta_desc, data_meta_type, pos_start, pos_end, reference_field_id, spec_field_name)
values(450001,450,'��ʼ������ά��','1','19','.','','@busi_date');

delete from aade.param_dictionary t where t.dicttable='9333';
insert into aade.param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9333', '01', '01-��ʼ������ά��', null, null, '1');

delete from aade.param_dict_list t where t.dicttable='9333';
insert into aade.param_dict_list(dicttable, dicttablename, datatype, opright, dicttabledescription)
values('9333','���޹������ڹ�������','','','');



commit;



