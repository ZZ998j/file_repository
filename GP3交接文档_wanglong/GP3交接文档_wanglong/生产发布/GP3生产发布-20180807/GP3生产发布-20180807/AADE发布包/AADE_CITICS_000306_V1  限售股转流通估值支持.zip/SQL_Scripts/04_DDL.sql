drop table SRC.ZZ_NTS_BASIC;
-- Create table
create table SRC.ZZ_NTS_BASIC
(
  gzr     VARCHAR2(8),
  gpdm    VARCHAR2(6),
  xsqjsr  VARCHAR2(8),
  gfbdggr VARCHAR2(8),
  bl      VARCHAR2(10)
)
tablespace TS_SRC
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  )
nologging;
-- Create/Recreate indexes 
create index SRC.IDX_ZZ_NTS_BASIC_1 on SRC.ZZ_NTS_BASIC (gzr)
  tablespace TS_SRC_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );