--����--
 --SRC.ZZ_NTS_LIQ_DIS--
drop table SRC.ZZ_NTS_LIQ_DIS;  
create table SRC.ZZ_NTS_LIQ_DIS
(
  gzr     VARCHAR2(8),
  gpdm    VARCHAR2(6),
  xsqjsr  VARCHAR2(8),
  gfbdggr VARCHAR2(8),
  sshy    VARCHAR2(100),
  dyhyzs  VARCHAR2(6),
  syxsq   NUMBER(5),
  ldxzk   NUMBER(8,4),
  bl      VARCHAR2(10)
)
tablespace TS_SRC
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  )
nologging;
 --aade.quote-- 
 alter table aade.quote add RESTRICTSHARE VARCHAR2(12);
 alter table aade.quote add RESTRICTENDDATE VARCHAR2(8);
 --aaia.aaia_quote--
 alter table aaia.aaia_quote add RESTRICTSHARE VARCHAR2(12);
 alter table aaia.aaia_quote add RESTRICTENDDATE VARCHAR2(8);  
  --aade.quote_archive-- 
 alter table aade.quote_archive add RESTRICTSHARE VARCHAR2(12);
 alter table aade.quote_archive add RESTRICTENDDATE VARCHAR2(8);
 --aaia.aaia_quote_archive--
 alter table aaia.aaia_quote_archive add RESTRICTSHARE VARCHAR2(12);
 alter table aaia.aaia_quote_archive add RESTRICTENDDATE VARCHAR2(8);  
 
---��˾��Ϊ���洦����---
drop table NTS_LIQ_DIS_DATE_TEMP; 
create table NTS_LIQ_DIS_DATE_TEMP
(
  gpdm       VARCHAR2(6),
  gzr        VARCHAR2(8),
  source     VARCHAR2(3),
  datetype   VARCHAR2(8),
  datedata   VARCHAR2(8),
  calculated CHAR(1)
)
tablespace TS_AADE
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  )
nologging;
-- nts_liq_dis_date --
drop table nts_liq_dis_date;
create table NTS_LIQ_DIS_DATE
(
  gpdm       VARCHAR2(6),
  gzr        VARCHAR2(8),
  source     VARCHAR2(3),
  datetype   VARCHAR2(8),
  datedata   VARCHAR2(8),
  calculated CHAR(1),
  tmstmap    TIMESTAMP(6)
)
tablespace TS_AADE
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  )
nologging;


drop sequence AADE.SEQ_CSIL;
create sequence AADE.SEQ_CSIL
minvalue 1
maxvalue 99999
start with 1
increment by 1
cache 20
order;


drop table IDX_DISCOUNT_ASSET;
create table IDX_DISCOUNT_ASSET
(
  assetidentifier VARCHAR2(6),
  sourcetype      varchar2(6),
  gpdm            VARCHAR2(10),
  xsqjsr          VARCHAR2(10)
)
tablespace TS_AADE
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  )
nologging;



drop  table src.gp3_position;
create table src.gp3_position
(
PortfolioIdentifier char(24),
AssetIdentifier     char(48),
NewAssetIdentifier  char(48),
CustodianIdentifier char(32),
TradeType           char(6),
TradeStatus         char(24),
TradeDate           char(12),
TradeQuantity       number(22,5)
);
comment on table src.gp3_position
is 'GP3�ֱֲ�';
comment on column src.gp3_position.PortfolioIdentifier
is '��Ϻ�';
comment on column src.gp3_position.AssetIdentifier
is '֤ȯ����';
comment on column src.gp3_position.NewAssetIdentifier
is '��֤ȯ����';
comment on column src.gp3_position.CustodianIdentifier
is 'GP3����';
comment on column src.gp3_position.TradeType
is '��������';
comment on column src.gp3_position.TradeStatus
is '�ķ���';
comment on column src.gp3_position.TradeDate
is '��������';
comment on column src.gp3_position.TradeQuantity
is '��������';


drop table aade.gp3_position_compare;
create table aade.gp3_position_compare
(
AssetIdentifier     char(48),
AssetIdentifier_name     varchar2(20),
PortfolioIdentifier char(24),
status          char(10),
gpTradeDate           char(12),
compareresult       char(1),
zzTradeDate           char(12),
zzprice             NUMBER(17,8)
);
comment on table aade.gp3_position_compare
is 'GP3�ֲ����۽�ֹ�նԱȱ�';
comment on column aade.gp3_position_compare.AssetIdentifier
is '֤ȯ����';
comment on column aade.gp3_position_compare.AssetIdentifier_name
is '֤ȯ����';
comment on column aade.gp3_position_compare.PortfolioIdentifier
is '��ϴ���';
comment on column aade.gp3_position_compare.status
is '�ֲ�״̬';
comment on column aade.gp3_position_compare.gpTradeDate
is '���۽�ֹ��';
comment on column aade.gp3_position_compare.compareresult
is '�ԱȽ������ֹ�գ�';
comment on column aade.gp3_position_compare.zzTradeDate
is '��֤�����ڽ�ֹ��';
comment on column aade.gp3_position_compare.zzprice
is '��֤�ۿ���';
---------------miao����
create table aade.param_dictionary_map_000306 as
select * from aade.param_dictionary_map;

create table aade.param_data_source_000306 as
select * from aade.param_data_source;

create table aade.param_dictionary_000306 as
select * from aade.param_dictionary;

create table aade.data_field_info_000306 as
select * from aade.data_field_info;

create table aade.data_field_mapping_000306 as
select * from aade.data_field_mapping;

create table aade.param_businessflag_000306 as
select * from aade.param_businessflag;

drop table src.manual_lockperiod;
create table src.manual_lockperiod 
(tradetype   char(6),
tradedate    char(8),
settlementdate    char(8),
portfoliocode     char(6),
shareholdaccount  char(10),
assetidentifier   char(8),
tradequantity     number(18,2),
tradestatus       char(4),
assetclass        char(4),
imp_date          char(8)       
);
comment on column src.manual_lockperiod.tradetype
is '��������';
comment on column src.manual_lockperiod.tradedate
is '������';
comment on column src.manual_lockperiod.settlementdate
is '��������';
comment on column src.manual_lockperiod.portfoliocode
is '��ϴ���';
comment on column src.manual_lockperiod.shareholdaccount
is '�ɶ�����';
comment on column src.manual_lockperiod.assetidentifier
is '֤ȯ����';
comment on column src.manual_lockperiod.tradequantity
is 'ת��������';
comment on column src.manual_lockperiod.tradestatus
is '����Ŀ��';
comment on column src.manual_lockperiod.assetclass
is '�ʲ�����';
comment on column src.manual_lockperiod.imp_date
is '��������';