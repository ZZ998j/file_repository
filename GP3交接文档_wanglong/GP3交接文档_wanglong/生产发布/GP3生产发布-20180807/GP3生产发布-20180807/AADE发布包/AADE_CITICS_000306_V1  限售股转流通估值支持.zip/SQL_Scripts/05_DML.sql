DELETE param_dictionary WHERE TRIM(Dicttable)='9101' AND TRIM(ITEMCODE) = '20';
insert into param_dictionary (DICTTABLE, ITEMCODE, ITEMNAME_ZH, ITEMNAME_EN, ITEMDESCRIPTION, VALIDFLAG)
values ('9101', '20', '��֤���޹�Ʊ������Ϣ', null, null, '0');

DELETE param_data_source X where TRIM(X.Function_Id) ='1001020120';
insert into param_data_source (DATA_SOURCE_ID, FUNCTION_ID, DATA_SOURCE_TYPE, DATA_SOURCE_DISCRIPTION, DATA_SOURCE_NAME, SEPERATOR, HEADER, FOOTER, HAS_TITLE, BUSI_DATE_FIELD, DATA_FIELD, TARGET_TABLE_ID, TARGET_TABLE_NAME, PROCESS_ID, PROCESS_ORDER, IS_IMP_DEL_INFO, TARGET_TABLE_DISCRIPTION, FULL_PATH_JUDGE_FLAG)
values (650,'1001020120','3','��֤���޹�Ʊ������Ϣ�����ļ�                                                                                                               ','*nts_basic                                                   ','|', 0, 0, null,'GZR         ', null, 651,'src.zz_nts_basic                                             ', null, 0, null,'��֤���޹�Ʊ������Ϣ���ݱ�                                                                                                                ','1');

DELETE data_field_info WHERE data_source_id in (650,651);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (650001, 650,'GZR                          ','1', null, null, null, 1, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (650002, 650,'GPDM                         ','1', null, null, null, 2, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (650003, 650,'XSQJSR                       ','1', null, null, null, 3, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (650004, 650,'GFBDGGR                      ','1', null, null, null, 4, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (650005, 650,'BL                           ','1', null, null, null, 5, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (651001, 651,'GZR                          ','1', null, null, null, 1, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (651002, 651,'GPDM                         ','1', null, null, null, 2, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (651003, 651,'XSQJSR                       ','1', null, null, null, 3, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (651004, 651,'GFBDGGR                      ','1', null, null, null, 4, null);

insert into data_field_info (FIELD_ID, DATA_SOURCE_ID, FIELD_NAME, FIELD_TYPE, FIELD_POSITION, FIELD_LENGTH, FIELD_ROUND, FIELD_ORDER, DIVISOR)
values (651005, 651,'BL                           ','1', null, null, null, 5, null);

DELETE data_field_mapping WHERE FIELD_MAPPING_ID IN(select FIELD_ID from data_field_info WHERE data_source_id in (650,651));

insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (650001, 650001, 651001);

insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (650002, 650002, 651002);

insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (650003, 650003, 651003);

insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (650004, 650004, 651004);

insert into data_field_mapping (FIELD_MAPPING_ID, SOURCE_FIELD_ID, TARGET_FIELD_ID)
values (650005, 650005, 651005);

COMMIT;